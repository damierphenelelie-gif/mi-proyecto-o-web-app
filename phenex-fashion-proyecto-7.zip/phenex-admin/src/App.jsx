import { useState, useEffect } from 'react'

// Cambiá esto por la URL de tu backend en Render cuando lo despliegues.
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

const vacio = {
  nombre: '',
  categoria: '',
  descripcion: '',
  precio: '',
}

function authHeader() {
  const token = localStorage.getItem('phenex_token')
  return token ? { Authorization: `Bearer ${token}` } : {}
}

function LoginScreen({ onLogin }) {
  const [usuario, setUsuario] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const [cargando, setCargando] = useState(false)

  async function enviar(e) {
    e.preventDefault()
    setCargando(true)
    setError(null)
    try {
      const res = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuario, password })
      })
      if (!res.ok) throw new Error()
      const data = await res.json()
      localStorage.setItem('phenex_token', data.token)
      onLogin(data.token)
    } catch {
      setError('Usuario o contraseña incorrectos.')
    } finally {
      setCargando(false)
    }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={enviar}>
        <div className="wordmark" style={{ marginBottom: 28 }}>PHENEX<span>fashion</span></div>
        <div className="field">
          <label>Usuario</label>
          <input type="text" value={usuario} onChange={e => setUsuario(e.target.value)} required autoFocus />
        </div>
        <div className="field">
          <label>Contraseña</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} required />
        </div>
        <button type="submit" className="submit-btn" disabled={cargando}>
          {cargando ? 'Entrando...' : 'Entrar'}
        </button>
        {error && <div className="status-msg error">{error}</div>}
      </form>
    </div>
  )
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem('phenex_token'))
  const [form, setForm] = useState(vacio)
  const [fotos, setFotos] = useState([]) // [{url, archivo}]
  const [variantes, setVariantes] = useState([{ talle: '', color: '', cantidad_disponible: '' }])
  const [subiendoFoto, setSubiendoFoto] = useState(false)
  const [generandoDescripcion, setGenerandoDescripcion] = useState(false)
  const [guardando, setGuardando] = useState(false)
  const [status, setStatus] = useState(null) // {tipo: 'ok'|'error', texto}
  const [productos, setProductos] = useState([])
  const [dragover, setDragover] = useState(false)

  useEffect(() => { if (token) cargarProductos() }, [token])

  async function cargarProductos() {
    try {
      const res = await fetch(`${API_URL}/productos`, { headers: authHeader() })
      if (res.status === 401) { cerrarSesion(); return }
      const data = await res.json()
      setProductos(data)
    } catch {
      // el backend puede no estar corriendo todavía; no rompemos la UI por esto
    }
  }

  function cerrarSesion() {
    localStorage.removeItem('phenex_token')
    setToken(null)
  }

  function actualizarCampo(campo, valor) {
    setForm(prev => ({ ...prev, [campo]: valor }))
  }

  async function subirArchivos(archivos) {
    setSubiendoFoto(true)
    setStatus(null)
    try {
      for (const archivo of archivos) {
        const fd = new FormData()
        fd.append('file', archivo)
        const res = await fetch(`${API_URL}/productos/upload-imagen`, { method: 'POST', headers: authHeader(), body: fd })
        if (!res.ok) throw new Error('No se pudo subir la imagen')
        const data = await res.json()
        setFotos(prev => [...prev, { url: data.url, archivo }])
      }
    } catch (e) {
      setStatus({ tipo: 'error', texto: 'Error al subir la foto. Revisá que el backend esté corriendo.' })
    } finally {
      setSubiendoFoto(false)
    }
  }

  function quitarFoto(index) {
    setFotos(prev => prev.filter((_, i) => i !== index))
  }

  async function sugerirDescripcion() {
    if (fotos.length === 0) {
      setStatus({ tipo: 'error', texto: 'Subí al menos una foto para que la IA pueda describir el producto.' })
      return
    }
    setGenerandoDescripcion(true)
    setStatus(null)
    try {
      const fd = new FormData()
      fd.append('file', fotos[0].archivo)
      fd.append('nombre_producto', form.nombre)
      const res = await fetch(`${API_URL}/productos/generar-descripcion`, { method: 'POST', headers: authHeader(), body: fd })
      if (!res.ok) throw new Error()
      const data = await res.json()
      actualizarCampo('descripcion', data.descripcion.trim())
    } catch {
      setStatus({ tipo: 'error', texto: 'No se pudo generar la descripción. Probá de nuevo.' })
    } finally {
      setGenerandoDescripcion(false)
    }
  }

  function actualizarVariante(index, campo, valor) {
    setVariantes(prev => prev.map((v, i) => i === index ? { ...v, [campo]: valor } : v))
  }

  function agregarVariante() {
    setVariantes(prev => [...prev, { talle: '', color: '', cantidad_disponible: '' }])
  }

  function quitarVariante(index) {
    setVariantes(prev => prev.filter((_, i) => i !== index))
  }

  async function guardarProducto(e) {
    e.preventDefault()
    setGuardando(true)
    setStatus(null)
    try {
      const payload = {
        nombre: form.nombre,
        categoria: form.categoria,
        descripcion: form.descripcion,
        precio: parseFloat(form.precio) || 0,
        fotos: fotos.map(f => f.url),
        variantes: variantes
          .filter(v => v.talle || v.color)
          .map(v => ({ ...v, cantidad_disponible: parseInt(v.cantidad_disponible) || 0 }))
      }
      const res = await fetch(`${API_URL}/productos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeader() },
        body: JSON.stringify(payload)
      })
      if (!res.ok) throw new Error()
      setStatus({ tipo: 'ok', texto: 'Producto publicado en el catálogo.' })
      setForm(vacio)
      setFotos([])
      setVariantes([{ talle: '', color: '', cantidad_disponible: '' }])
      cargarProductos()
    } catch {
      setStatus({ tipo: 'error', texto: 'No se pudo guardar el producto. Revisá los datos.' })
    } finally {
      setGuardando(false)
    }
  }

  const totalStock = variantes.reduce((acc, v) => acc + (parseInt(v.cantidad_disponible) || 0), 0)

  if (!token) {
    return <LoginScreen onLogin={setToken} />
  }

  return (
    <div>
      <header className="topbar">
        <div className="wordmark">PHENEX<span>fashion</span></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <div className="topbar-sub">Panel de catálogo</div>
          <button onClick={cerrarSesion} className="logout-btn">Salir</button>
        </div>
      </header>

      <div className="layout">
        {/* ---------- FORMULARIO ---------- */}
        <div>
          <p className="eyebrow">Nueva prenda</p>
          <h1 className="section-title">Cargar producto</h1>

          <form className="card" onSubmit={guardarProducto}>
            <div className="field">
              <label>Fotos</label>
              <div
                className={`dropzone ${dragover ? 'dragover' : ''}`}
                onDragOver={(e) => { e.preventDefault(); setDragover(true) }}
                onDragLeave={() => setDragover(false)}
                onDrop={(e) => {
                  e.preventDefault(); setDragover(false)
                  subirArchivos(Array.from(e.dataTransfer.files))
                }}
                onClick={() => document.getElementById('input-foto').click()}
              >
                <div className="dropzone-label">
                  {subiendoFoto ? 'Subiendo...' : <><strong>Hacé clic</strong> o arrastrá las fotos acá</>}
                </div>
                <input
                  id="input-foto" type="file" accept="image/*" multiple
                  style={{ display: 'none' }}
                  onChange={(e) => subirArchivos(Array.from(e.target.files))}
                />
              </div>
              {fotos.length > 0 && (
                <div className="photo-strip">
                  {fotos.map((f, i) => (
                    <div className="photo-thumb" key={i}>
                      <img src={f.url} alt="" />
                      <button type="button" onClick={() => quitarFoto(i)}>×</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="field">
              <label>Nombre del producto</label>
              <input type="text" value={form.nombre}
                onChange={e => actualizarCampo('nombre', e.target.value)}
                placeholder="Vestido Bianca" required />
            </div>

            <div className="row-2">
              <div className="field">
                <label>Categoría</label>
                <input type="text" value={form.categoria}
                  onChange={e => actualizarCampo('categoria', e.target.value)}
                  placeholder="Vestidos" />
              </div>
              <div className="field">
                <label>Precio (ARS)</label>
                <input type="number" value={form.precio}
                  onChange={e => actualizarCampo('precio', e.target.value)}
                  placeholder="45000" required />
              </div>
            </div>

            <div className="field">
              <label>Descripción</label>
              <textarea value={form.descripcion}
                onChange={e => actualizarCampo('descripcion', e.target.value)}
                placeholder="Descripción que van a leer tus clientes..." />
              <button type="button" className="ia-suggest-btn"
                onClick={sugerirDescripcion} disabled={generandoDescripcion}>
                {generandoDescripcion ? 'Generando...' : '✨ Sugerir con IA a partir de la foto'}
              </button>
            </div>

            <div className="field">
              <label>Talles y colores</label>
              <div className="variantes-list">
                {variantes.map((v, i) => (
                  <div className="variante-row" key={i}>
                    <input type="text" placeholder="Talle (M)" value={v.talle}
                      onChange={e => actualizarVariante(i, 'talle', e.target.value)} />
                    <input type="text" placeholder="Color" value={v.color}
                      onChange={e => actualizarVariante(i, 'color', e.target.value)} />
                    <input type="number" placeholder="Stock" value={v.cantidad_disponible}
                      onChange={e => actualizarVariante(i, 'cantidad_disponible', e.target.value)} />
                    <button type="button" className="remove-variant"
                      onClick={() => quitarVariante(i)}>×</button>
                  </div>
                ))}
              </div>
              <button type="button" className="add-variant-btn" onClick={agregarVariante}>
                + Agregar variante
              </button>
            </div>

            <button type="submit" className="submit-btn" disabled={guardando}>
              {guardando ? 'Publicando...' : 'Publicar producto'}
            </button>

            {status && <div className={`status-msg ${status.tipo}`}>{status.texto}</div>}
          </form>

          {productos.length > 0 && (
            <>
              <p className="eyebrow" style={{ marginTop: 36 }}>Catálogo actual</p>
              <div className="product-list">
                {productos.map(p => (
                  <div className="product-list-item" key={p.id}>
                    <span className="nombre">{p.nombre}</span>
                    <span className="precio">${p.precio.toLocaleString('es-AR')}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        {/* ---------- VISTA PREVIA EN VIVO ---------- */}
        <div className="preview-wrap">
          <p className="preview-label">Así se va a ver</p>
          <div className="ficha">
            <div className="ficha-photo">
              {fotos.length > 0
                ? <img src={fotos[0].url} alt="" />
                : <span className="ficha-photo-placeholder">sin foto todavía</span>}
            </div>
            <div className="ficha-body">
              {form.categoria && <div className="ficha-categoria">{form.categoria}</div>}
              <h2 className="ficha-nombre">{form.nombre || 'Nombre del producto'}</h2>
              <div className="ficha-precio">
                {form.precio ? `$${parseFloat(form.precio).toLocaleString('es-AR')}` : '$ —'}
              </div>
              <p className="ficha-descripcion">
                {form.descripcion || 'La descripción va a aparecer acá.'}
              </p>
              <div className="ficha-tags">
                {variantes.filter(v => v.talle || v.color).map((v, i) => (
                  <span className="ficha-tag" key={i}>{[v.talle, v.color].filter(Boolean).join(' · ')}</span>
                ))}
                {totalStock > 0 && <span className="ficha-tag">{totalStock} unidades en stock</span>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
