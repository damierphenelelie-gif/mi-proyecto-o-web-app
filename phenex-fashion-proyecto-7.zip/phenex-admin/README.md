# Phenex Fashion — Panel de administración

Panel para cargar productos con fotos, generar la descripción con IA, y definir
talles/colores con su stock. Se conecta directo a tu backend de FastAPI.

## Instalación

```bash
cd phenex-admin
npm install
cp .env.example .env
```

Si tu backend corre local en el puerto 8000 (como en el README del backend), no
hace falta tocar el `.env`. Si ya lo desplegaste en Render, poné ahí la URL real:

```
VITE_API_URL=https://tu-backend.onrender.com
```

## Correrlo

```bash
npm run dev
```

Se abre en `http://localhost:5173`. Importante: el backend tiene que estar
corriendo al mismo tiempo (`uvicorn app.main:app --reload` desde la carpeta
`phenex-backend`) para que el panel pueda guardar productos y subir fotos.

## Qué hace cada parte

- **Subir fotos**: arrastrás o seleccionás las fotos, se suben al backend
  (`/productos/upload-imagen`) y quedan guardadas.
- **"Sugerir con IA"**: manda la primera foto a Claude, que analiza la prenda
  y te devuelve una descripción de venta lista para editar o publicar tal cual.
- **Talles y colores**: cada fila es una variante con su propio stock — así el
  asistente de WhatsApp sabe exactamente qué hay disponible.
- **Vista previa**: se actualiza en vivo con lo que vas cargando, para que veas
  cómo va a quedar la ficha antes de publicar.

## Para producción

- Las fotos hoy se guardan en el disco del backend. Antes de ir a producción en
  Render conviene migrar a Cloudinary o S3 (el disco de Render no es persistente
  entre despliegues) — es un cambio acotado, solo en la función `subir_imagen`
  del backend.
- Desplegar este panel es tan simple como `npm run build` y subir la carpeta
  `dist/` a Vercel, Netlify, o como página estática en Render.
