const CACHE_NAME = 'phenex-admin-v1';
const ARCHIVOS_BASE = ['/', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ARCHIVOS_BASE))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Estrategia simple: red primero, y si falla (sin conexión) usa lo cacheado.
// Las llamadas a la API del backend NO se cachean, siempre van a la red,
// porque necesitamos datos de stock/precio actualizados en tiempo real.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  const esLlamadaApi = url.pathname.startsWith('/productos') || url.pathname.startsWith('/auth');

  if (esLlamadaApi) return; // deja pasar directo a la red

  event.respondWith(
    fetch(event.request)
      .then((res) => {
        const copia = res.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copia));
        return res;
      })
      .catch(() => caches.match(event.request))
  );
});
