# Mi Asistente Personal-Profesional — MVP inicial

Aplicación web instalable (PWA) para uso privado de Isaías Mejía. Esta primera base incluye interfaz responsive, navegación y registro local de tareas, ingresos/gastos, clientes, ventas, contenido, hábitos, notas y consultas guardadas.

## Importante antes de usar datos reales
- Esta versión es un prototipo inicial. Los datos se guardan en `localStorage` del navegador; no hay cuenta, cifrado, copia automática ni sincronización en la nube.
- La sección IA guarda consultas, pero no responde con IA real hasta conectar un backend seguro y un proveedor de IA.
- WhatsApp e Instagram son pantallas preparatorias. No se conectan automáticamente y requieren configuración y permisos oficiales.
- No ingreses información muy sensible en esta versión inicial.
- El service worker ofrece una primera base offline, no una garantía de que todos los recursos estén disponibles sin conexión.

## Ejecutar en un entorno de desarrollo
Requiere Node.js 20 o una versión compatible reciente.

```bash
npm install
npm run dev
```

## Compilar
```bash
npm run build
```
El resultado se genera en `dist/`. Para publicar, sube el proyecto a GitHub y conecta el repositorio con Netlify. En Netlify:
- Build command: `npm run build`
- Publish directory: `dist`

## Próximas etapas necesarias
1. Probar y ajustar este MVP.
2. Añadir backend y autenticación privada.
3. Añadir base de datos y copias de seguridad cifradas.
4. Crear endpoint de IA que mantenga la clave fuera del navegador.
5. Evaluar las APIs oficiales y permisos de WhatsApp e Instagram.
6. Probar la instalación PWA y el funcionamiento offline en Android.

## Privacidad
No publiques el repositorio como un sistema seguro solo por ser privado. La privacidad real exige autenticación, autorización en servidor, reglas de base de datos y protección de secretos.
