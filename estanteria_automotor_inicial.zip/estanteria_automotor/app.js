const $ = (id) => document.getElementById(id);
const guides = {
  "no-start": {
    title: "Guía inicial: el auto no arranca",
    warning: "Si hay humo, olor fuerte a combustible o cables calientes, no sigas intentando arrancar. Alejate y pedí asistencia.",
    steps: [
      "Con el vehículo detenido, caja en P o punto muerto según corresponda y freno de mano aplicado, observá si se encienden las luces del tablero.",
      "Al intentar arrancar una sola vez, ¿el motor gira, se escucha un clic o no ocurre nada? No repitas intentos largos.",
      "Si las luces están muy débiles o se apagan, la batería o sus conexiones podrían estar descargadas o flojas. No manipules bornes si no sabés hacerlo con seguridad.",
      "Si las luces son normales pero solo se oye un clic, puede haber un problema en el circuito de arranque. Requiere revisión técnica."
    ],
    conclusion: "Esta observación no confirma una causa. Si no arranca, solicitá diagnóstico profesional."
  },
  "engine-light": {
    title: "Guía inicial: luz del motor encendida",
    warning: "Si la luz parpadea, el motor tiembla, pierde mucha potencia o hay olor a combustible, detenete en un lugar seguro y pedí asistencia.",
    steps: [
      "Con el auto detenido, identificá si la luz queda fija o parpadea.",
      "Observá si hay vibraciones, ruidos nuevos, humo u olor inusual. No acerques las manos a piezas móviles.",
      "Si el vehículo funciona normalmente y la luz queda fija, anotá cuándo apareció. La lectura de códigos OBD-II puede orientar el diagnóstico.",
      "No cambies sensores ni borres códigos solo por una sospecha. Guardá los códigos para el mecánico."
    ],
    conclusion: "La luz por sí sola no identifica una pieza averiada. Hace falta leer los códigos y evaluarlos con el contexto del vehículo."
  },
  "overheat": {
    title: "Guía inicial: el auto se calienta",
    warning: "Si la temperatura llega a la zona roja, detenete en un lugar seguro y apagá el motor. Nunca abras el radiador ni el depósito caliente: puede expulsar líquido hirviendo.",
    steps: [
      "No continúes circulando con temperatura excesiva. Esperá a que el motor se enfríe por completo.",
      "Solo cuando esté completamente frío, observá desde afuera el nivel del depósito transparente, si es visible.",
      "Buscá manchas debajo del auto sin meterte debajo del vehículo ni tocar mangueras calientes.",
      "No agregues líquido a un motor caliente ni sigas viaje si vuelve a subir la temperatura."
    ],
    conclusion: "Una fuga, un ventilador, un termostato u otros componentes pueden estar involucrados. Pedí revisión profesional antes de volver a circular."
  },
  "lights": {
    title: "Guía inicial: luces que no funcionan",
    warning: "No trabajes con cables pelados ni con circuitos mojados. Si hay olor a quemado o humo, apagá el vehículo y pedí asistencia.",
    steps: [
      "Con el vehículo detenido, identificá qué luces fallan: faros, posición, giro, freno o interior.",
      "Pedí a otra persona que observe las luces de freno mientras accionás el pedal, sin mover el vehículo.",
      "Consultá el manual del vehículo para localizar el fusible correspondiente. No coloques uno de mayor amperaje.",
      "Si el fusible vuelve a quemarse o hay cables dañados, no sigas probando: necesita revisión técnica."
    ],
    conclusion: "Puede tratarse de una lámpara, fusible, conexión o circuito. La revisión visual no confirma el origen."
  }
};
const systems = {
  "Mecánica general": "Incluye lubricación, correas, motor, embrague, caja, suspensión y dirección. En esta versión se ofrecen descripciones educativas; no se indican desmontajes complejos.",
  "Motor e inyección": "Incluye sensores, actuadores, alimentación de combustible y ECU. Para identificar piezas y procedimientos exactos hace falta conocer la versión y el motor del vehículo.",
  "Eléctrica, luces y tablero": "Incluye batería, alternador, arranque, fusibles, relés, luces e indicadores. Evitá puentear relés o manipular cableado sin formación.",
  "Refrigeración": "Incluye radiador, termostato, bomba de agua, mangueras, depósito y ventilador. Nunca abras el circuito con el motor caliente.",
  "Frenos": "Sistema crítico de seguridad. Esta biblioteca no guía purgas, desmontajes ni reparaciones de frenos. Ante pérdida de frenado o fuga, no circules y solicitá asistencia.",
  "Piezas": "El catálogo completo se incorporará progresivamente y deberá validarse por marca, modelo, año, versión y motorización. Una misma pieza puede cambiar de ubicación según la versión."
};
function loadVehicle(){
  const v = JSON.parse(localStorage.getItem("ea_vehicle") || "null");
  if(v){ $("make").value=v.make||""; $("model").value=v.model||""; $("year").value=v.year||""; $("vehicleStatus").textContent=`Vehículo guardado: ${v.make} ${v.model} ${v.year}`; }
}
function loadHistory(){
  const items=JSON.parse(localStorage.getItem("ea_history")||"[]");
  $("history").innerHTML="";
  if(!items.length){$("history").innerHTML="<li>Aún no hay revisiones registradas.</li>";return;}
  items.slice().reverse().forEach(x=>{const li=document.createElement("li");li.textContent=`${x.date} — ${x.title}`;$("history").appendChild(li);});
}
function saveHistory(title){
  const items=JSON.parse(localStorage.getItem("ea_history")||"[]");
  items.push({title,date:new Date().toLocaleString("es-AR")});
  localStorage.setItem("ea_history",JSON.stringify(items));loadHistory();
}
$("saveVehicle").addEventListener("click",()=>{
  const v={make:$("make").value.trim(),model:$("model").value.trim(),year:$("year").value.trim()};
  if(!v.make||!v.model||!v.year){$("vehicleStatus").textContent="Completá marca, modelo y año.";return;}
  localStorage.setItem("ea_vehicle",JSON.stringify(v));$("vehicleStatus").textContent=`Vehículo guardado: ${v.make} ${v.model} ${v.year}`;
});
document.querySelectorAll("[data-guide]").forEach(btn=>btn.addEventListener("click",()=>{
  const g=guides[btn.dataset.guide];
  $("guide").classList.remove("hidden");
  $("guide").innerHTML=`<h3>${g.title}</h3><p><strong>Seguridad:</strong> ${g.warning}</p><ol>${g.steps.map(s=>`<li>${s}</li>`).join("")}</ol><p><strong>Conclusión orientativa:</strong> ${g.conclusion}</p><p class="muted">Guía educativa; no reemplaza la evaluación de un profesional.</p><button id="saveGuide">Guardar esta revisión</button>`;
  $("saveGuide").addEventListener("click",()=>saveHistory(g.title),{once:true});
  $("guide").scrollIntoView({behavior:"smooth",block:"start"});
}));
document.querySelectorAll("[data-system]").forEach(btn=>btn.addEventListener("click",()=>{
  const name=btn.dataset.system;
  $("systemInfo").classList.remove("hidden");
  $("systemInfo").innerHTML=`<strong>${name}</strong><p>${systems[name]}</p>`;
}));
$("clearHistory").addEventListener("click",()=>{if(confirm("¿Borrar el historial guardado en este dispositivo?")){localStorage.removeItem("ea_history");loadHistory();}});
$("obdInfo").addEventListener("click",()=>{
  $("obdMessage").classList.remove("hidden");
  $("obdMessage").textContent="Necesitaremos un adaptador OBD-II compatible con tu vehículo y el tipo de conexión admitido por el teléfono. Esta versión todavía no se conecta al adaptador ni interpreta datos en vivo.";
});
if("serviceWorker" in navigator){window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));}
loadVehicle();loadHistory();