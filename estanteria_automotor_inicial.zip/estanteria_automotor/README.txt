ESTANTERÍA AUTOMOTOR — VERSIÓN INICIAL

Qué incluye:
- Interfaz web adaptable a celular.
- Selección y guardado local de marca, modelo y año.
- Guías iniciales de cuatro síntomas.
- Biblioteca básica por sistemas.
- Historial local de revisiones.
- Estructura PWA y caché offline básica.

Limitaciones:
- No incluye todavía IA real/API.
- No incluye conexión real a OBD-II.
- No contiene una base completa validada de vehículos 2010–2026.
- No certifica diagnósticos ni reparaciones.
- El modo offline requiere abrir primero la aplicación con conexión y que el navegador permita Service Workers (normalmente HTTPS o localhost).

Siguiente etapa:
Publicar los archivos en un alojamiento HTTPS elegido por el usuario y comprobar la instalación desde Chrome Android. No introducir claves secretas de API dentro de app.js; para IA real necesitaremos un backend seguro.
